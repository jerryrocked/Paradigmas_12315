import java.util.Vector;

public class Principal {
    public static void main(String[] args) { // Programa principal
        // Definir varias formas diferentes
        Rectangulo rectangulo1 = new Rectangulo("Rectángulo 1", "Azul", 12, 18);
        Rectangulo rectangulo2 = new Rectangulo("Rectángulo 2", "Verde", 7, 12);

        // Pruebas del punto 1, comprobar el funcionamiento de las funciones
        rectangulo1.Imprimir();
        rectangulo1.CalcularArea();
        rectangulo1.CambiarTamaño(2);
        rectangulo1.CalcularPerimetro();

        rectangulo2.Imprimir();
        rectangulo2.CalcularArea();
        rectangulo2.CambiarTamaño(0.5);
        rectangulo2.CalcularPerimetro();

        // Definir varias formas diferentes
        Elipse elipse1 = new Elipse("Elipse 1", "Blanco", 6.2, 4.8);
        Elipse elipse2 = new Elipse("Elipse 2", "Rojo", 9.7, 6.8);

        Cuadrado cuadrado1 = new Cuadrado("Cuadrado 1", "Amarrillo", 10);
        Cuadrado cuadrado2 = new Cuadrado("Cuadrado 2", "Cafe", 9);

        Circulo circulo1 = new Circulo("Circulo 1", "Rosa", 8);
        Circulo circulo2 = new Circulo("Circulo 2", "Violeta", 9.2);

        Vector<Forma> formas = new Vector<Forma>(); // Crear vector de objetos tipo Forma
        // Agregar las formas definidas
        formas.add(rectangulo1);
        formas.add(rectangulo2);
        formas.add(elipse1);
        formas.add(elipse2);
        formas.add(cuadrado1);
        formas.add(cuadrado2);
        formas.add(circulo1);
        formas.add(circulo2);

        int min = -10, max = 10, x, y;

        for (int i = 0; i < formas.size(); i++) { // Generar buclo para recorrer todas las formas
            x = (int) (Math.random() * (max - min + 1) + min); // Genera aleatorio un número entre -10 y 10 para X
            y = (int) (Math.random() * (max - min + 1) + min); // Genera aleatorio un número entre -10 y 10 para Y

            formas.get(i).CambiarColor("Azul"); // Poner las formas del mismo color
            formas.get(i).MoverCoordenadaCentro(new Punto(x, y)); // Mover las formas a un punto en especifico
            formas.get(i).Imprimir(); // Imprime los datos de la forma
        }
    }
}
