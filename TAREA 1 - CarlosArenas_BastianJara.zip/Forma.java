class Forma {
    private String nombre;
    private String color;
    private Punto coordenadaCentro;

    public Forma() { // Contructor por defecto
        this.nombre = "";
        this.color = "";
        this.coordenadaCentro = new Punto();
    }

    public Forma(String nombre, String color) { // Constructor con parametros
        this.nombre = nombre;
        this.color = color;
        this.coordenadaCentro = new Punto();
    }

    public void Imprimir() { // Imprimir
        System.out.println("\n== Forma ==");
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Color: " + this.ObtenerColor());
        System.out.println("Centro: " + this.coordenadaCentro.toString());
    }

    public String ObtenerColor() { // Función para obtener el color
        return color;
    }

    public void CambiarColor(String color) { // Función para cambiar el color
        this.color = color;
    }

    public void MoverCoordenadaCentro(Punto coordenadaCentro) { // Función para mover la coordenada centro
        this.coordenadaCentro = coordenadaCentro;
    }
}