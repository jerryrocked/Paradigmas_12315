public class Circulo extends Elipse {
    public Circulo() { // Constructor por defector
        super();
    }

    public Circulo(String nombre, String color, double radio) { // Constructor con parametros
        super(nombre, color, radio, radio);
    }
}
