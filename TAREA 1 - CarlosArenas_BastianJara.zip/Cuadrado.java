public class Cuadrado extends Rectangulo {
    public Cuadrado() { // Constructor por defecto
        super();
    }

    public Cuadrado(String nombre, String color, double lado) { // Constructor con parametros
        super(nombre, color, lado, lado);
    }
}
