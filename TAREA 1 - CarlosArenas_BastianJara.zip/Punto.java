public class Punto {
    private int x;
    private int y;

    public Punto() { // Constructor por defecto
        this.x = 0;
        this.y = 0;
    }

    public Punto(int x, int y) { // Constructor con parametros
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() { // Regresa los datos del punto
        return ("(X = " + this.x + ", Y = " + this.y + ")");
    }
}
