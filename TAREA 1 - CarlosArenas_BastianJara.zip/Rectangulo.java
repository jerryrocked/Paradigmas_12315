public class Rectangulo extends Forma {
    private double ladoMenor;
    private double ladoMayor;

    public Rectangulo() { // Constructor por defector
        super();
        this.ladoMenor = 0;
        this.ladoMayor = 0;
    }

    public Rectangulo(String nombre, String color, double ladoMenor, double ladoMayor) { // Constructor con parametros
        super(nombre, color);

        this.ladoMenor = ladoMenor;
        this.ladoMayor = ladoMayor;
    }

    @Override
    public void Imprimir() { // Función para imprimir los datos
        super.Imprimir();
        System.out.println("Lado Menor: " + this.ladoMenor);
        System.out.println("Lado Mayor: " + this.ladoMayor);
    }

    public void CalcularArea() { // Función para calcular el area del rectangulo
        double area = (this.ladoMenor * this.ladoMayor);

        System.out.println("Área: " + area);
    }

    public void CalcularPerimetro() { // Función para calcular el perimetro del rectangulo
        double perimetro = ((2 * this.ladoMenor) + (2 * this.ladoMayor));

        System.out.println("Perímetro: " + perimetro);
    }

    public void CambiarTamaño(double factorEscala) { // Función para cambiar el tamaño del rectangulo
        this.ladoMenor *= factorEscala;
        this.ladoMayor *= factorEscala;
    }
}
