public class Elipse extends Forma {
    private double radioMayor;
    private double radioMenor;

    public Elipse() { // Constructor por defecto
        super();

        this.radioMayor = 0;
        this.radioMenor = 0;
    }

    public Elipse(String nombre, String color, double radioMayor, double radioMenor) { // Constructor con parametros
        super(nombre, color);
        this.radioMayor = radioMayor;
        this.radioMenor = radioMenor;
    }

    public void CalcularArea() { // Función para calcular el área del elipse
        double area = Math.PI * (this.radioMayor * this.radioMenor);

        System.out.println("Área: " + area);
    }

    @Override
    public void Imprimir() { // Función para imprimir los datos
        super.Imprimir();
        System.out.println("Radio Mayor: " + this.radioMayor);
        System.out.println("Radio Menor: " + this.radioMenor);
    }
}
