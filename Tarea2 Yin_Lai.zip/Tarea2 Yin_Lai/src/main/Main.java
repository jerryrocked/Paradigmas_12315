package main;

import BaseDatos.Conexion;


public class Main {
    public static void main(String[] args){
        Conexion date = new Conexion();
        date.getConnection();
    
    }
    
    
}
