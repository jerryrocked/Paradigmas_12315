package BaseDatos;


public class ModificarDatos {
    private final Conexion conexion;
    
    public ModificarDatos()
    {
        conexion = new Conexion();
    }
}
