/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BaseDatos;

/**
 *
 * @author v_e_c
 */
public class EnviarDatos {
   /*public EnviarDatos(){
       conexion = new Conexion();
   }*/
    
    
    
    
    
}
